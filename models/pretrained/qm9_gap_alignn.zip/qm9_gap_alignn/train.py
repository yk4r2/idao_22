from alignn.train_props import train_prop_model 
train_prop_model(dataset="qm9_std_jctc",prop="gap")
